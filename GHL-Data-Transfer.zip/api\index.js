// Vercel serverless entry point — re-exports the Express app from server.js
export { default } from '../server.js';
